CREATE DATABASE `xqwyglxt`;
USE `xqwyglxt`;

DROP TABLE IF EXISTS `楼房`;
CREATE TABLE `楼房` (
    `楼号` INT PRIMARY KEY,
    `户数` INT,
    `物业费标准` DOUBLE
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `房屋`;
CREATE TABLE `房屋` (
    `楼号` INT,
    `房号` INT,
    `面积` DOUBLE,
    `楼层` INT,
    PRIMARY KEY (楼号, 房号),
    FOREIGN KEY (楼号) REFERENCES 楼房(楼号)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `业主`;
CREATE TABLE `业主` (
    `身份证号` VARCHAR(20) PRIMARY KEY,
    `姓名` VARCHAR(50),
    `性别` VARCHAR(10),
    `工作单位` VARCHAR(100),
    `电话` VARCHAR(20),
    `家庭人口` INT
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `物业员`;
CREATE TABLE `物业员` (
    `工号` VARCHAR(20) PRIMARY KEY,
    `姓名` VARCHAR(50),
    `性别` VARCHAR(10),
    `年龄` INT,
    `电话` VARCHAR(20)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX idx_owner_name ON 业主(姓名);
DROP TABLE IF EXISTS `物业管理情况`;
CREATE TABLE 物业管理情况 (
    `日期` DATE,
    `业主姓名` VARCHAR(50),
    `要求` TEXT,
    `处理情况` ENUM('满意', '不满意'),
    `物业员工号` VARCHAR(20),
    PRIMARY KEY (日期, 业主姓名),
    FOREIGN KEY (业主姓名) REFERENCES 业主(姓名),
    FOREIGN KEY (物业员工号) REFERENCES 物业员(工号)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `物业费信息`;
CREATE TABLE `物业费信息` (
    `楼号` INT,
    `房号` INT,
    `缴费日期` DATE,
    `起始日期` DATE,
    `终止日期` DATE,
    `金额` DOUBLE,
    PRIMARY KEY (楼号, 房号, 缴费日期),
    FOREIGN KEY (楼号, 房号) REFERENCES 房屋(楼号, 房号)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
